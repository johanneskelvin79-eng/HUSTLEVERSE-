// HUSTLEVERSE — Supabase-connected frontend
// Add your Supabase Project URL and publishable/anon key below.
// Never place a service_role/secret key in browser code.
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
const configured = /^https:\/\/.+/.test(SUPABASE_URL) &&
  !SUPABASE_URL.includes("YOUR_") && !SUPABASE_ANON_KEY.includes("YOUR_");
const db = configured && window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

let currentUser = null, isSignup = false, selectedOpportunity = null, isAdmin = false;
const $ = id => document.getElementById(id);
const show = (id,on=true)=>$(id)?.classList.toggle("hidden",!on);
function message(id,text,error=false){const el=$(id);if(!el)return;el.textContent=text;el.classList.toggle("error",error);}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function openAuth(signup=false){
  isSignup=signup;
  $("auth-title").innerHTML=signup?'Create your <em>account.</em>':'Welcome <em>back.</em>';
  $("auth-subtitle").textContent=signup?'Join HUSTLEVERSE for free.':'Log in to continue to HUSTLEVERSE.';
  $("auth-submit").textContent=signup?'Create account':'Log in';
  $("switch-copy").textContent=signup?'Already have an account?':'New to HUSTLEVERSE?';
  $("switch-auth").textContent=signup?'Log in':'Create an account';
  show("name-wrap",signup);message("auth-message","");show("auth-modal");
}
function closeModals(){show("auth-modal",false);show("apply-modal",false);show("listing-modal",false);}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",closeModals));
["auth-modal","apply-modal","listing-modal"].forEach(id=>$(id)?.addEventListener("click",e=>{if(e.target.id===id)closeModals()}));
$("auth-open").onclick=()=>openAuth(false);$("hero-join").onclick=()=>openAuth(true);$("switch-auth").onclick=()=>openAuth(!isSignup);
$("logout").onclick=async()=>{if(db)await db.auth.signOut();};
$("refresh").onclick=loadOpportunities;
$("auth-form").addEventListener("submit",async e=>{
 e.preventDefault();if(!db)return message("auth-message","Supabase is not configured. Add your project URL and public key in app.js.",true);
 const email=$("email").value.trim(),password=$("password").value,name=$("full-name").value.trim();
 $("auth-submit").disabled=true;
 try{
  const result=isSignup
   ? await db.auth.signUp({email,password,options:{data:{full_name:name},emailRedirectTo:location.origin}})
   : await db.auth.signInWithPassword({email,password});
  if(result.error)throw result.error;
  message("auth-message",isSignup?"Account created. Check your email to confirm it, then log in.":"Logged in successfully.");
  if(!isSignup)setTimeout(closeModals,700);
 }catch(err){message("auth-message",err.message,true)}finally{$("auth-submit").disabled=false;}
});
async function loadOpportunities(){
 if(!db){$("setup-notice").classList.remove("hidden");$("opportunity-list").innerHTML='<div class="empty-state">Connect Supabase to load live opportunities.</div>';return;}
 $("setup-notice").classList.add("hidden");
 const {data,error}=await db.from("opportunities").select("id,title,description,category,location,compensation,created_at").eq("is_published",true).order("created_at",{ascending:false});
 if(error){$("opportunity-list").innerHTML=`<div class="empty-state">Could not load listings: ${escapeHtml(error.message)}</div>`;return;}
 if(!data?.length){$("opportunity-list").innerHTML='<div class="empty-state">No verified opportunities have been published yet. Check back soon.</div>';return;}
 $("opportunity-list").innerHTML=data.map(o=>`<article class="op-card"><span class="op-tag">${escapeHtml(o.category||"Opportunity")}</span><h3>${escapeHtml(o.title)}</h3><p>${escapeHtml(o.description||"Details coming soon.")}</p><div class="op-meta">${escapeHtml(o.location||"Remote / Not specified")} · ${escapeHtml(o.compensation||"Compensation to be discussed")}</div><button class="btn btn-outline apply-btn" data-id="${o.id}">View / apply ↗</button></article>`).join("");
 document.querySelectorAll(".apply-btn").forEach(b=>b.onclick=()=>startApply(data.find(o=>o.id===b.dataset.id)));
}
function startApply(o){
 if(!currentUser)return openAuth(false);
 selectedOpportunity=o;$("apply-title").textContent=o.title;message("apply-message","");show("apply-modal");
}
$("apply-form").addEventListener("submit",async e=>{
 e.preventDefault();if(!db||!currentUser||!selectedOpportunity)return;
 const btn=$("apply-form").querySelector("button");btn.disabled=true;
 const {error}=await db.from("applications").insert({opportunity_id:selectedOpportunity.id,user_id:currentUser.id,cover_note:$("cover-note").value.trim()});
 if(error)message("apply-message",error.message,true);
 else{message("apply-message","Application submitted. Track it in your dashboard.");$("cover-note").value="";await loadDashboard();setTimeout(closeModals,1200);}
 btn.disabled=false;
});
async function loadDashboard(){
 if(!db||!currentUser){$("dashboard-content").innerHTML='<div class="empty-state">Log in or create an account to open your dashboard.</div>';return;}
 const {data,error}=await db.from("applications").select("id,status,created_at,opportunities(title)").eq("user_id",currentUser.id).order("created_at",{ascending:false});
 if(error){$("dashboard-content").textContent=error.message;return;}
 const rows=(data||[]).map(a=>`<div class="application"><span>${escapeHtml(a.opportunities?.title||"Opportunity")}</span><span class="status">${escapeHtml(a.status||"submitted")}</span></div>`).join("");
 $("dashboard-content").innerHTML=`<div class="eyebrow">SIGNED IN AS</div><p>${escapeHtml(currentUser.email)}</p><h3>Your applications (${data?.length||0})</h3>${rows||'<div class="empty-state">You have not applied to any opportunities yet.</div>'}`;
}
async function checkAdmin(){
 if(!currentUser)return false;
 const {data:{user}}=await db.auth.getUser();
 return user?.app_metadata?.role==="admin";
}
function updateAuthUI(){
 show("auth-open",!currentUser);show("logout",!!currentUser);
 $("user-label").textContent=currentUser?(currentUser.user_metadata?.full_name||currentUser.email):"";
 loadDashboard();
}
async function loadAdmin(){
 if(!db||!isAdmin)return;
 const [opps,apps]=await Promise.all([
  db.from("opportunities").select("*").order("created_at",{ascending:false}),
  db.from("applications").select("id,status,cover_note,created_at,profiles(full_name),opportunities(title)").order("created_at",{ascending:false})
 ]);
 if(opps.error||apps.error){$("admin-content").textContent=opps.error?.message||apps.error?.message;return;}
 const listingRows=(opps.data||[]).map(o=>`<div class="admin-row"><div><b>${escapeHtml(o.title)}</b><small>${escapeHtml(o.category||"") } · ${o.is_published?"Published":"Draft"}</small></div><div class="admin-actions"><button class="btn btn-outline" data-publish="${o.id}" data-state="${o.is_published}">${o.is_published?"Unpublish":"Publish"}</button><button class="btn btn-outline" data-delete="${o.id}">Delete</button></div></div>`).join("");
 const appRows=(apps.data||[]).map(a=>`<div class="admin-row"><div><b>${escapeHtml(a.opportunities?.title||"Opportunity")}</b><small>${escapeHtml(a.profiles?.full_name||"Applicant")} · ${escapeHtml(a.status)}</small></div><select data-status="${a.id}"><option ${a.status==="submitted"?"selected":""}>submitted</option><option ${a.status==="reviewing"?"selected":""}>reviewing</option><option ${a.status==="accepted"?"selected":""}>accepted</option><option ${a.status==="declined"?"selected":""}>declined</option></select></div>`).join("");
 $("admin-content").innerHTML=`<h3>Opportunity listings</h3>${listingRows||"<p>No listings yet.</p>"}<h3>Applications</h3>${appRows||"<p>No applications yet.</p>"}`;
 document.querySelectorAll("[data-publish]").forEach(b=>b.onclick=async()=>{const {error}=await db.from("opportunities").update({is_published:b.dataset.state!=="true"}).eq("id",b.dataset.publish);if(error)alert(error.message);else loadAdmin(),loadOpportunities();});
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(!confirm("Delete this opportunity and its applications?"))return;const {error}=await db.from("opportunities").delete().eq("id",b.dataset.delete);if(error)alert(error.message);else loadAdmin(),loadOpportunities();});
 document.querySelectorAll("[data-status]").forEach(s=>s.onchange=async()=>{const {error}=await db.from("applications").update({status:s.value}).eq("id",s.dataset.status);if(error)alert(error.message);});
}
$("new-listing").onclick=()=>{if(!isAdmin)return; $("listing-form").reset();message("listing-message","");show("listing-modal");};
$("listing-form").addEventListener("submit",async e=>{
 e.preventDefault();if(!isAdmin)return;
 const payload={title:$("listing-title").value.trim(),description:$("listing-description").value.trim(),category:$("listing-category").value.trim(),location:$("listing-location").value.trim(),compensation:$("listing-compensation").value.trim(),is_published:$("listing-published").checked,created_by:currentUser.id};
 const {error}=await db.from("opportunities").insert(payload);
 if(error)message("listing-message",error.message,true);else{message("listing-message","Listing saved.");await loadAdmin();await loadOpportunities();setTimeout(closeModals,800);}
});
async function init(){
 if(!db){loadOpportunities();return;}
 const {data:{session}}=await db.auth.getSession();currentUser=session?.user||null;
 isAdmin=await checkAdmin();updateAuthUI();show("admin-section",isAdmin);loadOpportunities();if(isAdmin)loadAdmin();
 db.auth.onAuthStateChange(async(_event,session)=>{currentUser=session?.user||null;isAdmin=await checkAdmin();updateAuthUI();show("admin-section",isAdmin);if(isAdmin)loadAdmin();});
}
init();
