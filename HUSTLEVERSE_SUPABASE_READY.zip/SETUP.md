# HUSTLEVERSE — Supabase-ready website

This ZIP contains the website frontend and SQL for a real Supabase-backed MVP. It is not live-connected until you add your own Supabase project credentials and deploy the files to Netlify.

## Included
- Email/password signup and login
- Public published-opportunity marketplace
- Authenticated applications and personal application dashboard
- Admin-only listing creation, publishing/unpublishing, deletion and application status management
- Supabase row-level security policies

## Connect Supabase (required)
1. Create a project at https://supabase.com/dashboard.
2. Open SQL Editor → New query. Paste all of `supabase/schema.sql` and run it.
3. Open Project Settings → API. Copy the Project URL and the publishable key (or legacy anon/public key).
4. In `app.js`, replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`.
   Never use a `service_role` or secret key in browser code.
5. In Supabase → Authentication → URL Configuration, set Site URL to your Netlify URL and add that URL to Redirect URLs.
6. Deploy the extracted folder to Netlify (Netlify Drop or your existing site's deploy flow).

## Make your account admin
1. Register on the live website and confirm your email.
2. In Supabase → Authentication → Users, copy your account UUID.
3. In SQL Editor, run the admin promotion SQL at the bottom of `supabase/schema.sql`, replacing `YOUR-USER-UUID`.
4. Sign out and sign back in. The Admin workspace will appear.

## Important
- Admin role is stored in protected `app_metadata`; do not let users set their own role from signup metadata.
- Only publish opportunities you have checked and have permission to advertise.
- This MVP does not include payments, commission payouts, identity verification, chat, or automatic job verification.
- Do not collect bank details, passwords for other services, or identity documents in this MVP.
