-- HUSTLEVERSE Supabase schema — run once in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 created_at timestamptz not null default now()
);
create table if not exists public.opportunities (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text not null default '',
 category text,
 location text,
 compensation text,
 is_published boolean not null default false,
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);
create table if not exists public.applications (
 id uuid primary key default gen_random_uuid(),
 opportunity_id uuid not null references public.opportunities(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 cover_note text default '',
 status text not null default 'submitted' check(status in ('submitted','reviewing','accepted','declined')),
 created_at timestamptz not null default now(),
 unique(opportunity_id,user_id)
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name)
 values(new.id,new.raw_user_meta_data->>'full_name')
 on conflict(id) do update set full_name=excluded.full_name;
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.opportunities enable row level security;
alter table public.applications enable row level security;

drop policy if exists "Profiles are viewable by owner" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Published opportunities are public" on public.opportunities;
drop policy if exists "Admins can insert opportunities" on public.opportunities;
drop policy if exists "Admins can update opportunities" on public.opportunities;
drop policy if exists "Admins can delete opportunities" on public.opportunities;
drop policy if exists "Users can see own applications" on public.applications;
drop policy if exists "Users can apply as themselves" on public.applications;
drop policy if exists "Admins can update application status" on public.applications;

create policy "Profiles owner read" on public.profiles for select to authenticated using(auth.uid()=id);
create policy "Profiles owner update" on public.profiles for update to authenticated using(auth.uid()=id) with check(auth.uid()=id);
create policy "Published opportunities visible" on public.opportunities for select using(is_published=true or (auth.uid() is not null and (auth.jwt()->'app_metadata'->>'role')='admin'));
create policy "Admins create opportunities" on public.opportunities for insert to authenticated with check((auth.jwt()->'app_metadata'->>'role')='admin');
create policy "Admins edit opportunities" on public.opportunities for update to authenticated using((auth.jwt()->'app_metadata'->>'role')='admin') with check((auth.jwt()->'app_metadata'->>'role')='admin');
create policy "Admins remove opportunities" on public.opportunities for delete to authenticated using((auth.jwt()->'app_metadata'->>'role')='admin');
create policy "Applicants and admins read applications" on public.applications for select to authenticated using(auth.uid()=user_id or (auth.jwt()->'app_metadata'->>'role')='admin');
create policy "Authenticated users apply as self" on public.applications for insert to authenticated with check(auth.uid()=user_id and exists(select 1 from public.opportunities o where o.id=opportunity_id and o.is_published=true));
create policy "Admins update application status" on public.applications for update to authenticated using((auth.jwt()->'app_metadata'->>'role')='admin') with check((auth.jwt()->'app_metadata'->>'role')='admin');

grant usage on schema public to anon, authenticated;
grant select on public.opportunities to anon, authenticated;
grant select,insert,update,delete on public.opportunities to authenticated;
grant select,insert,update on public.applications to authenticated;
grant select,update on public.profiles to authenticated;

-- After creating your own account, promote only your account to admin
-- by replacing the UUID with your user ID from Authentication > Users:
-- update auth.users
-- set raw_app_meta_data = coalesce(raw_app_meta_data,'{}'::jsonb) || '{"role":"admin"}'::jsonb
-- where id = 'YOUR-USER-UUID';
