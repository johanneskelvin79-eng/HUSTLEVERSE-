HUSTLEVERSE WEBSITE PROTOTYPE v1.0

FILES
- index.html: responsive mobile-friendly prototype. Open it in a browser.

WHAT WORKS
- Responsive landing page and navigation
- Opportunity category filters and keyword search
- Opportunity submission form with basic required-field checks
- Demo submissions saved in local browser storage on the device that submitted them

IMPORTANT LIMITATIONS
- This is a front-end prototype, not a production marketplace.
- Example listings are explicitly placeholders, not real jobs or verified offers.
- Form submissions are NOT sent to an owner, database, email, or public website. They remain only in that browser/device.
- No accounts, authentication, moderation dashboard, server database, or secure messaging yet.
- Do not publish it as a live vacancy platform until a real backend, privacy notice, moderation process, and verified listing workflow are connected.

FREE FIRST DEPLOYMENT (Netlify Drop)
1. Extract the ZIP on your computer, or keep the folder accessible in your phone's file manager.
2. Open https://app.netlify.com/drop in a browser and sign in / create a free account.
3. Upload the extracted folder named hustleverse_v1 (or drag the folder onto the page from a computer).
4. Netlify will provide a temporary public URL. Rename the site in Netlify site settings if the option is available.
5. Test the site on your phone and share only as an early preview, clearly explaining that submissions are local demo drafts.

NEXT PRODUCTION STEP
Connect a real hosted database and form endpoint, add owner notifications and moderation, publish privacy/terms pages, and replace all placeholder cards with verified opportunities and consented business contacts.
